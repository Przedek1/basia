module.exports = {
    name: "ping-pong",
    description: "odpowiada pong",

    run(msg) {
        msg.reply('Pong!')
    }
}