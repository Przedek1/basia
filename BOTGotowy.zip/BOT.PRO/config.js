module.exports = {
token: "NzAyODgwNTIwNjk0MTM2OTA2.XqVDfg.5Iabzbr6BdVpGc-kenz93yDKmGc",
prefix: "*"

}